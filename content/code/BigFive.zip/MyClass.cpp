/**
 * Author: Sadab Hafiz
 * Date: 06/06/2024
 * Description: Implementation of MyClass
 * Reference: https://en.cppreference.com/w/cpp/language/rule_of_three
 */

#include "MyClass.hpp"
#include <iostream>

MyClass::MyClass() : data{nullptr}, size{0} {
    std::cout << "Default constructor invoked" << std::endl;
}

MyClass::MyClass(int size) : size{size} {
    data = new int[size];
    std::cout << "Parametrized constructor invoked" << std::endl;
}

MyClass::MyClass(const MyClass& other) : size{other.size} {
    data = new int[size];
    // Copy the items from other object
    for (int i = 0; i < size; i++) {
        data[i] = other.data[i];
    }
    std::cout << "Copy constructor invoked" << std::endl;
}

MyClass::MyClass(MyClass&& other) : data{other.data}, size{other.size} {
    other.data = nullptr;
    other.size = 0;
    std::cout << "Move constructor invoked" << std::endl;
}

MyClass::~MyClass() {
    delete[] data;
    std::cout << "Destructor invoked" << std::endl;
}

MyClass& MyClass::operator=(const MyClass& other) {
    // if the object being copied from is not this object
    // delete the current data and deep copy the data from other
    if (this != &other) {
        delete[] data;
        size = other.size;
        data = new int[size];
        for (int i = 0; i < size; i++) {
            data[i] = other.data[i];
        }
    }
    std::cout << "Copy assignment operator invoked" << std::endl;
    return *this;
}

MyClass& MyClass::operator=(MyClass&& other) {
    // if the object being moved from is not this object
    // delete the current data and shallow copy the data from other
    if (this != &other) {
        delete[] data;
        data = other.data;
        size = other.size;
        other.data = nullptr;
        other.size = 0;
    }
    std::cout << "Move assignment operator invoked" << std::endl;
    return *this;
}

