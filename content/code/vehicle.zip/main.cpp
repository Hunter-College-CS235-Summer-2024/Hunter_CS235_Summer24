// Author: Sadab Hafiz
// Date: 05-30-2024
// Main function to test the Vehicle and Car class

#include <iostream>
#include "vehicle.hpp"
#include "car.hpp"

int main(){
    Vehicle generic;
    Car suv;
    std::cout << generic << std::endl;
    std::cout << suv << std::endl;
}
